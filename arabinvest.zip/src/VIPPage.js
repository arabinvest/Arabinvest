import React from "react";
import { Button } from "./components/ui/button";

export default function VIPPage() {
  return (
    <div className="min-h-screen bg-black text-white flex flex-col items-center justify-start p-4">
      <h1 className="text-2xl font-bold my-4">arabinvest</h1>
      <div className="bg-[#1b1b1b] rounded-2xl w-full max-w-md p-4 space-y-4">
        <div className="bg-gradient-to-r from-yellow-400 to-red-500 p-4 rounded-xl text-center">
          <h2 className="text-lg font-bold">VIP المميز</h2>
          <p className="text-sm mt-2">استمتع بأفضل الخدمات والعروض الحصرية لأعضاء VIP.</p>
          <Button className="mt-4 w-full bg-white text-black font-bold">اشترك الآن</Button>
        </div>

        <div className="bg-[#2a2a2a] p-3 rounded-xl space-y-2">
          <div className="flex justify-between text-sm">
            <span>صلاحية العضوية:</span>
            <span>30 يوم</span>
          </div>
          <div className="flex justify-between text-sm">
            <span>السعر:</span>
            <span>$9.99</span>
          </div>
        </div>

        <div className="bg-[#2a2a2a] p-3 rounded-xl text-center">
          <p className="text-sm">اضغط أدناه لتحميل التطبيق والاستفادة من العضوية:</p>
          <Button className="mt-3 w-full bg-blue-600 text-white font-bold">تحميل التطبيق</Button>
        </div>

        <div className="bg-[#2a2a2a] p-3 rounded-xl">
          <h3 className="text-md font-bold mb-2 text-center">عناوين الدفع:</h3>
          <div className="text-sm break-words">
            <p><strong>TRC20:</strong> TShW6za4ydQakybXEpSFS9TBPBWTbtdoiS</p>
            <p><strong>DEP20:</strong> 0xdbcd82282db7c62955d716c8a9b3dba87d4dee7c</p>
          </div>
        </div>
      </div>

      <footer className="mt-8 text-xs text-gray-400">© 2025 جميع الحقوق محفوظة</footer>
    </div>
  );
}
